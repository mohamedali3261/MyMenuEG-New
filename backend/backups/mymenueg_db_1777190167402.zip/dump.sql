-- MyMenuEG SQL Dump
-- Generated: 2026-04-26T07:56:07.284Z
-- Tables: 27

SET FOREIGN_KEY_CHECKS=0;

-- Table: admins (2 rows)
TRUNCATE TABLE admins;
INSERT INTO admins (id, username, password, email, permissions, is_super_admin, is_active, last_login, created_at, updated_at) VALUES ('adm-1776953072126', 'moali', '$2b$12$WuQo2FX4/oB/zBuD9m7xnu4PIX5455AWexHgRe0CkvB.pcpjgFwEC', 'aboali11@aa.aa', '["orders","products","categories","customers","coupons","pages","slides"]', 0, 1, NULL, 'Sun Apr 26 2026 13:28:49 GMT+0300 (Eastern European Summer Time)', NULL);
INSERT INTO admins (id, username, password, email, permissions, is_super_admin, is_active, last_login, created_at, updated_at) VALUES ('admin-1', 'admin', '$2b$12$dwOsh3JFMLePYlKzf/7lPO749nv3Rgi2LmSdCbfTRLsMZ/dP1w5Dq', 'admin@mymenueg.com', '["all"]', 1, 1, 'Sun Apr 26 2026 10:55:54 GMT+0300 (Eastern European Summer Time)', 'Sun Apr 26 2026 13:28:49 GMT+0300 (Eastern European Summer Time)', NULL);

-- Table: customers (empty)
TRUNCATE TABLE customers;

-- Table: categories (1 rows)
TRUNCATE TABLE categories;
INSERT INTO categories (id, name_ar, name_en, icon, status, subtitle_ar, subtitle_en) VALUES ('CAT-1777056352408', 'كوب', 'cup', 'Tag', 'active', '', '');

-- Table: settings (32 rows)
TRUNCATE TABLE settings;
INSERT INTO settings (key_name, value) VALUES ('backgroundStyle', 'blobs');
INSERT INTO settings (key_name, value) VALUES ('blend_colors', 'false');
INSERT INTO settings (key_name, value) VALUES ('bundleCardStyle', 'A');
INSERT INTO settings (key_name, value) VALUES ('cardHoverAnimation', 'zoom');
INSERT INTO settings (key_name, value) VALUES ('cardStyle', 'floating');
INSERT INTO settings (key_name, value) VALUES ('contact_settings', '{"heroTitleAr":"تواصل معنا - نحن هنا لمساعدتك","heroTitleEn":"Contact Us - We\'re Here to Help","heroSubtitleAr":"سواء كان لديك استفسار حول منتجاتنا، أو طلبات بالجملة، أو تحتاج إلى تصميم مخصص لمعدات مطعمك، فريقنا خبير وجاهز لتقديم الدعم الكامل عبر جميع وسائل التواصل.","heroSubtitleEn":"Whether you have an inquiry about our products, wholesale orders, or need custom designs for your restaurant supplies, our expert team is ready to fully support you.","formTitleAr":"أرسل لنا رسالة مباشرة","formTitleEn":"Send us a direct message","formSubtitleAr":"يرجى تعبئة النموذج أدناه وسيقوم أحد ممثلي المبيعات أو الدعم الفني بالرد عليك في غضون 24 ساعة كحد أقصى.","formSubtitleEn":"Please fill out the form below and one of our sales or technical support representatives will get back to you within 24 hours.","submitBtnAr":"إرسال الرسالة الآن","submitBtnEn":"Send Message Now","whatsapp":"+20 123 456 789","phone":"+20 123 456 789","email":"hello@mymenueg.com","addressAr":"القاهرة، مصر - شارع التسعين","addressEn":"90th St, Cairo, Egypt","workingHoursAr":"الأحد - الخميس: 9:00 AM - 6:00 PM | السبت: 10:00 AM - 4:00 PM","workingHoursEn":"Sun - Thu: 9:00 AM - 6:00 PM | Sat: 10:00 AM - 4:00 PM"}');
INSERT INTO settings (key_name, value) VALUES ('faq_settings', '{"enabled":true,"items":[{"qAr":"كيف يمكنني تتبع طلبي؟","qEn":"How can I track my order?","aAr":"يمكنك تتبع طلبك من خلال صفحة \\"تتبع الطلبات\\" باستخدام رقم الطلب الخاص بك والذي يظهر لك بعد إتمام الشراء.","aEn":"You can track your order through the \\"Track Order\\" page using your order number provided after purchase."},{"qAr":"هل الدفع عند الاستلام متوفر؟","qEn":"Is Cash on Delivery (COD) available?","aAr":"نعم، نحن نوفر خدمة الدفع عند الاستلام كخيار أساسي ومجاني لجميع المحافظات.","aEn":"Yes, Cash on Delivery is available as a primary and free option for all governorates."}]}');
INSERT INTO settings (key_name, value) VALUES ('google_client_id', '');
INSERT INTO settings (key_name, value) VALUES ('google_login_enabled', 'false');
INSERT INTO settings (key_name, value) VALUES ('gsapSliderInterval', '0');
INSERT INTO settings (key_name, value) VALUES ('hideEmptySlider', 'true');
INSERT INTO settings (key_name, value) VALUES ('light_bg_color', '#e2e8f0');
INSERT INTO settings (key_name, value) VALUES ('logo_url', '');
INSERT INTO settings (key_name, value) VALUES ('marquee_animation_duration', '8');
INSERT INTO settings (key_name, value) VALUES ('marquee_bar1_color', '#eb5e28');
INSERT INTO settings (key_name, value) VALUES ('marquee_bar2_color', '#10b981');
INSERT INTO settings (key_name, value) VALUES ('marquee_enabled', 'true');
INSERT INTO settings (key_name, value) VALUES ('navbar_style', 'variant3');
INSERT INTO settings (key_name, value) VALUES ('notfound_settings', '{"titleAr":"أوبس! صفحة مفقودة.","titleEn":"Oops! Page Missing","descAr":"يبدو أن الصفحة التي تبحث عنها غير موجودة، ربما تم تغيير الرابط أو إزالتها.","descEn":"It looks like the page you are looking for doesn\'t exist, it might have been moved or removed."}');
INSERT INTO settings (key_name, value) VALUES ('payment_settings', '{"onlinePaymentEnabled":false,"cod":true,"paymob":false,"fawry":false,"wallet":false,"paymobApiKey":"","paymobIntegrationId":"","fawryMerchantCode":"","fawrySecurityKey":""}');
INSERT INTO settings (key_name, value) VALUES ('popup_settings', '{"enabled":false,"titleAr":"خصم خاص!","titleEn":"Special Offer!","descAr":"اشترك في نشرتنا الإخبارية واحصل على خصم 10%","descEn":"Subscribe to our newsletter and get 10% off","imageUrl":"","actionLink":"/products","actionTextAr":"تسوق الآن","actionTextEn":"Shop Now","delaySeconds":5}');
INSERT INTO settings (key_name, value) VALUES ('primary_color', '#f04800');
INSERT INTO settings (key_name, value) VALUES ('promo_enabled', 'false');
INSERT INTO settings (key_name, value) VALUES ('promo_text_ar', '');
INSERT INTO settings (key_name, value) VALUES ('promo_text_en', '');
INSERT INTO settings (key_name, value) VALUES ('secondary_color', '#10b981');
INSERT INTO settings (key_name, value) VALUES ('shipping_settings', '{"freeShippingEnabled":true,"freeShippingMinOrder":0,"flatRateShipping":0,"governorateRates":{}}');
INSERT INTO settings (key_name, value) VALUES ('sliderInterval', '3');
INSERT INTO settings (key_name, value) VALUES ('store_name', 'MyMenuEG');
INSERT INTO settings (key_name, value) VALUES ('whatsapp_enabled', 'false');
INSERT INTO settings (key_name, value) VALUES ('whatsapp_message', '');
INSERT INTO settings (key_name, value) VALUES ('whatsapp_phone', '');

-- Table: products (1 rows)
TRUNCATE TABLE products;
INSERT INTO products (id, name_ar, name_en, description_ar, description_en, price, old_price, stock, status, image_url, category_id, is_best_seller, shipping_info_ar, shipping_info_en, warranty_info_ar, warranty_info_en, video_url, view_count, carton_details_ar, carton_details_en, page_id, brand_ar, brand_en, material_ar, material_en, dimensions_ar, dimensions_en, usage_notes_ar, usage_notes_en, template_key, created_at, updated_at, allow_custom_print) VALUES ('prod-1777056527484', 'أكواب بلاستيك مطبوعة', 'Printed Plastic Cups', 'أكواب عالية الجودة مناسبة للكافيهات والمطاعم مع إمكانية الطباعة.', 'High-quality cups suitable for cafes and restaurants with branding options.', 200, 250, 22, 'active', '/uploads/products/cup/printed-plastic-cups/printed-plastic-cups_1777056511898.webp', 'CAT-1777056352408', 0, 'الشحن خلال 48 ساعة داخل القاهرة و72 ساعة للمحافظات.', 'Shipping within 48 hours in Cairo and 72 hours for other cities.', 'استبدال خلال 7 أيام في حالة عيوب الصناعة.', 'Replacement within 7 days for manufacturing defects.', '', 0, 'الكرتونة تحتوي على 1000 كوب.', 'Carton contains 1000 cups.', 'PAGE-1777056440401', 'MyMenuEG', 'MyMenuEG', 'بلاستيك غذائي', 'Food-grade plastic', 'قطر 9 سم × ارتفاع 11 سم (12 أونصة)', '9 cm diameter × 11 cm height (12 oz)', 'مناسب للمشروبات الباردة والساخنة حسب النوع.', 'Suitable for cold and hot beverages based on cup type.', 'cups', NULL, NULL, 0);

-- Table: hero_slides (empty)
TRUNCATE TABLE hero_slides;

-- Table: coupons (empty)
TRUNCATE TABLE coupons;

-- Table: store_pages (1 rows)
TRUNCATE TABLE store_pages;
INSERT INTO store_pages (id, name_ar, name_en, slug, is_dynamic, show_in_navbar, order_index, created_at, meta_desc, meta_title, status, content_ar, content_en, hide_empty, icon, layout_style, banner_url, banner_size, views, spotlight_product_id, countdown_end_date, show_search, image_url) VALUES ('PAGE-1777056440401', 'المستهلكات', 'aasdhgf', 'slug', 1, 1, 0, 'Sun Apr 26 2026 13:28:49 GMT+0300 (Eastern European Summer Time)', NULL, NULL, 'active', NULL, NULL, 1, NULL, 'grid', '/uploads/banners/1777185691485_586.webp', 'medium', 8, NULL, NULL, 0, '/uploads/general/1777056640888_170.webp');

-- Table: orders (empty)
TRUNCATE TABLE orders;

-- Table: notifications (empty)
TRUNCATE TABLE notifications;

-- Table: contact_submissions (empty)
TRUNCATE TABLE contact_submissions;

-- Table: refresh_tokens (1 rows)
TRUNCATE TABLE refresh_tokens;
INSERT INTO refresh_tokens (id, admin_id, token_hash, user_agent, ip_address, expires_at, created_at) VALUES ('31d0b15a-24b9-4169-923f-00bb124d16e8', 'admin-1', 'a5d42d1b8b6b81a6fbc501816817f0908ab148afbb33c7243752d5a3a96521bc', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '127.0.0.1', 'Sun May 03 2026 10:55:54 GMT+0300 (Eastern European Summer Time)', 'Sun Apr 26 2026 10:55:54 GMT+0300 (Eastern European Summer Time)');

-- Table: customer_wishlists (empty)
TRUNCATE TABLE customer_wishlists;

-- Table: customer_carts (empty)
TRUNCATE TABLE customer_carts;

-- Table: customer_notifications (empty)
TRUNCATE TABLE customer_notifications;

-- Table: order_items (empty)
TRUNCATE TABLE order_items;

-- Table: product_specs (2 rows)
TRUNCATE TABLE product_specs;
INSERT INTO product_specs (id, product_id, key_ar, key_en, val_ar, val_en) VALUES (1, 'prod-1777056527484', 'نوع الطباعة', 'Printing Type', 'أوفست', 'Offset');
INSERT INTO product_specs (id, product_id, key_ar, key_en, val_ar, val_en) VALUES (2, 'prod-1777056527484', 'الاستخدام', 'Usage', 'مطاعم وكافيهات', 'Restaurants & Cafes');

-- Table: product_images (1 rows)
TRUNCATE TABLE product_images;
INSERT INTO product_images (id, product_id, url) VALUES (1, 'prod-1777056527484', '/uploads/products/cup/printed-plastic-cups/printed-plastic-cups_1777056511898.webp');

-- Table: product_quantity_prices (2 rows)
TRUNCATE TABLE product_quantity_prices;
INSERT INTO product_quantity_prices (id, product_id, quantity_label, price, old_price) VALUES (1, 'prod-1777056527484', '1000', 200, 300);
INSERT INTO product_quantity_prices (id, product_id, quantity_label, price, old_price) VALUES (2, 'prod-1777056527484', '2000', 300, 400);

-- Table: product_detail_items (1 rows)
TRUNCATE TABLE product_detail_items;
INSERT INTO product_detail_items (id, product_id, label_ar, label_en, value_ar, value_en, order_index) VALUES (1, 'prod-1777056527484', 'عدد القطع بالكرتونة', 'Pieces per Carton', '1000 قطعة', '1000 pcs', 0);

-- Table: product_faqs (empty)
TRUNCATE TABLE product_faqs;

-- Table: product_variants (empty)
TRUNCATE TABLE product_variants;

-- Table: product_variant_images (empty)
TRUNCATE TABLE product_variant_images;

-- Table: product_bundle_items (empty)
TRUNCATE TABLE product_bundle_items;

-- Table: product_fbt (empty)
TRUNCATE TABLE product_fbt;

-- Table: product_reviews (empty)
TRUNCATE TABLE product_reviews;

SET FOREIGN_KEY_CHECKS=1;
