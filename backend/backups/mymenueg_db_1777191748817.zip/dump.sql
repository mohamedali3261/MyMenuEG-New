-- MyMenuEG SQL Dump
-- Generated: 2026-04-26T08:22:28.688Z
-- Tables: 32

SET FOREIGN_KEY_CHECKS=0;

-- Table: admins (2 rows)
TRUNCATE TABLE admins;
INSERT INTO admins (id, username, password, email, permissions, is_super_admin, is_active, last_login, created_at, updated_at) VALUES ('adm-1776953072126', 'moali', '$2b$12$WuQo2FX4/oB/zBuD9m7xnu4PIX5455AWexHgRe0CkvB.pcpjgFwEC', 'aboali11@aa.aa', '["orders","products","categories","customers","coupons","pages","slides"]', 0, 1, NULL, 'Sun Apr 26 2026 13:28:49 GMT+0300 (Eastern European Summer Time)', NULL);
INSERT INTO admins (id, username, password, email, permissions, is_super_admin, is_active, last_login, created_at, updated_at) VALUES ('admin-1', 'admin', '$2b$12$dwOsh3JFMLePYlKzf/7lPO749nv3Rgi2LmSdCbfTRLsMZ/dP1w5Dq', 'admin@mymenueg.com', '["all"]', 1, 1, 'Sun Apr 26 2026 11:21:57 GMT+0300 (Eastern European Summer Time)', 'Sun Apr 26 2026 13:28:49 GMT+0300 (Eastern European Summer Time)', NULL);

-- Table: customers (empty)
TRUNCATE TABLE customers;

-- Table: categories (empty)
TRUNCATE TABLE categories;

-- Table: settings (empty)
TRUNCATE TABLE settings;

-- Table: products (empty)
TRUNCATE TABLE products;

-- Table: hero_slides (empty)
TRUNCATE TABLE hero_slides;

-- Table: coupons (empty)
TRUNCATE TABLE coupons;

-- Table: gsap_slides (empty)
TRUNCATE TABLE gsap_slides;

-- Table: store_pages (empty)
TRUNCATE TABLE store_pages;

-- Table: orders (empty)
TRUNCATE TABLE orders;

-- Table: notifications (empty)
TRUNCATE TABLE notifications;

-- Table: contact_submissions (empty)
TRUNCATE TABLE contact_submissions;

-- Table: backup_logs (1 rows)
TRUNCATE TABLE backup_logs;
INSERT INTO backup_logs (id, action, admin_username, details, created_at) VALUES (1, 'wipe', 'admin', 'Full wipe with safety snapshot', 'Sun Apr 26 2026 11:18:18 GMT+0300 (Eastern European Summer Time)');

-- Table: refresh_tokens (1 rows)
TRUNCATE TABLE refresh_tokens;
INSERT INTO refresh_tokens (id, admin_id, token_hash, user_agent, ip_address, expires_at, created_at) VALUES ('e8643221-9b49-4d2f-b021-0d9c6a72dca3', 'admin-1', 'e2de1a79cc028f47af5660a9d10d024ddf247eaf04e0d454ea38b98f5f78c92f', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '127.0.0.1', 'Sun May 03 2026 11:21:57 GMT+0300 (Eastern European Summer Time)', 'Sun Apr 26 2026 11:21:57 GMT+0300 (Eastern European Summer Time)');

-- Table: customer_wishlists (empty)
TRUNCATE TABLE customer_wishlists;

-- Table: customer_carts (empty)
TRUNCATE TABLE customer_carts;

-- Table: customer_notifications (empty)
TRUNCATE TABLE customer_notifications;

-- Table: order_items (empty)
TRUNCATE TABLE order_items;

-- Table: product_specs (empty)
TRUNCATE TABLE product_specs;

-- Table: product_images (empty)
TRUNCATE TABLE product_images;

-- Table: product_quantity_prices (empty)
TRUNCATE TABLE product_quantity_prices;

-- Table: product_detail_items (empty)
TRUNCATE TABLE product_detail_items;

-- Table: product_faqs (empty)
TRUNCATE TABLE product_faqs;

-- Table: product_variants (empty)
TRUNCATE TABLE product_variants;

-- Table: product_variant_images (empty)
TRUNCATE TABLE product_variant_images;

-- Table: product_bundle_items (empty)
TRUNCATE TABLE product_bundle_items;

-- Table: product_fbt (empty)
TRUNCATE TABLE product_fbt;

-- Table: product_reviews (empty)
TRUNCATE TABLE product_reviews;

-- Table: marquee_settings (1 rows)
TRUNCATE TABLE marquee_settings;
INSERT INTO marquee_settings (id, enabled, created_at) VALUES ('main', 1, 'Sun Apr 26 2026 11:18:23 GMT+0300 (Eastern European Summer Time)');

-- Table: marquee_logos (empty)
TRUNCATE TABLE marquee_logos;

-- Table: svg_marquee (1 rows)
TRUNCATE TABLE svg_marquee;
INSERT INTO svg_marquee (id, left_text_1, left_text_2, right_text_1, right_text_2, text_color, animation_duration, show_can, show_bg_svg, can_image_url, font_family, enabled, created_at) VALUES ('main', 'Sip, smile, repeat', 'Taste the sparkle', 'Sip, smile, repeat', 'Taste the sparkle', '#ff0000', 15, 1, 1, NULL, 'Lilita One, sans-serif', 1, 'Sun Apr 26 2026 11:18:23 GMT+0300 (Eastern European Summer Time)');

-- Table: svg_marquee_items (empty)
TRUNCATE TABLE svg_marquee_items;

SET FOREIGN_KEY_CHECKS=1;
