-- MyMenuEG SQL Dump
-- Generated: 2026-04-26T08:05:17.572Z
-- Tables: 32

SET FOREIGN_KEY_CHECKS=0;

-- Table: admins (2 rows)
TRUNCATE TABLE admins;
INSERT INTO admins (id, username, password, email, permissions, is_super_admin, is_active, last_login, created_at, updated_at) VALUES ('adm-1776953072126', 'moali', '$2b$12$WuQo2FX4/oB/zBuD9m7xnu4PIX5455AWexHgRe0CkvB.pcpjgFwEC', 'aboali11@aa.aa', '["orders","products","categories","customers","coupons","pages","slides"]', 0, 1, NULL, 'Sun Apr 26 2026 13:28:49 GMT+0300 (Eastern European Summer Time)', NULL);
INSERT INTO admins (id, username, password, email, permissions, is_super_admin, is_active, last_login, created_at, updated_at) VALUES ('admin-1', 'admin', '$2b$12$dwOsh3JFMLePYlKzf/7lPO749nv3Rgi2LmSdCbfTRLsMZ/dP1w5Dq', 'admin@mymenueg.com', '["all"]', 1, 1, 'Sun Apr 26 2026 11:05:06 GMT+0300 (Eastern European Summer Time)', 'Sun Apr 26 2026 13:28:49 GMT+0300 (Eastern European Summer Time)', NULL);

-- Table: customers (empty)
TRUNCATE TABLE customers;

-- Table: categories (empty)
TRUNCATE TABLE categories;

-- Table: settings (empty)
TRUNCATE TABLE settings;

-- Table: products (empty)
TRUNCATE TABLE products;

-- Table: hero_slides (empty)
TRUNCATE TABLE hero_slides;

-- Table: coupons (empty)
TRUNCATE TABLE coupons;

-- Table: store_pages (empty)
TRUNCATE TABLE store_pages;

-- Table: orders (empty)
TRUNCATE TABLE orders;

-- Table: notifications (empty)
TRUNCATE TABLE notifications;

-- Table: contact_submissions (empty)
TRUNCATE TABLE contact_submissions;

-- Table: backup_logs (1 rows)
TRUNCATE TABLE backup_logs;
INSERT INTO backup_logs (id, action, admin_username, details, created_at) VALUES (1, 'wipe', 'admin', 'Full wipe with safety snapshot', 'Sun Apr 26 2026 10:56:09 GMT+0300 (Eastern European Summer Time)');

-- Table: refresh_tokens (1 rows)
TRUNCATE TABLE refresh_tokens;
INSERT INTO refresh_tokens (id, admin_id, token_hash, user_agent, ip_address, expires_at, created_at) VALUES ('e562f29c-8d9a-41eb-98b4-117130a1acb4', 'admin-1', 'ef4f4c6b07fb5879c9427489ef9d88650240cdcf254432e0d54e23a870a90344', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '127.0.0.1', 'Sun May 03 2026 11:05:06 GMT+0300 (Eastern European Summer Time)', 'Sun Apr 26 2026 11:05:06 GMT+0300 (Eastern European Summer Time)');

-- Table: customer_wishlists (empty)
TRUNCATE TABLE customer_wishlists;

-- Table: customer_carts (empty)
TRUNCATE TABLE customer_carts;

-- Table: customer_notifications (empty)
TRUNCATE TABLE customer_notifications;

-- Table: order_items (empty)
TRUNCATE TABLE order_items;

-- Table: product_specs (empty)
TRUNCATE TABLE product_specs;

-- Table: product_images (empty)
TRUNCATE TABLE product_images;

-- Table: product_quantity_prices (empty)
TRUNCATE TABLE product_quantity_prices;

-- Table: product_detail_items (empty)
TRUNCATE TABLE product_detail_items;

-- Table: product_faqs (empty)
TRUNCATE TABLE product_faqs;

-- Table: product_variants (empty)
TRUNCATE TABLE product_variants;

-- Table: product_variant_images (empty)
TRUNCATE TABLE product_variant_images;

-- Table: product_bundle_items (empty)
TRUNCATE TABLE product_bundle_items;

-- Table: product_fbt (empty)
TRUNCATE TABLE product_fbt;

-- Table: product_reviews (empty)
TRUNCATE TABLE product_reviews;

-- Table: gsap_slides (2 rows)
TRUNCATE TABLE gsap_slides;
INSERT INTO gsap_slides (id, place, title, title2, description, image, btn_link, page_id, order_index, created_at) VALUES ('GSAP-1777060746123', 'المكان', 'TITLE', 'SUBTITLE', 'الوصف هنا...', '/uploads/general/1777060777040_657.webp', '/products', NULL, 0, 'Fri Apr 24 2026 22:59:46 GMT+0300 (Eastern European Summer Time)');
INSERT INTO gsap_slides (id, place, title, title2, description, image, btn_link, page_id, order_index, created_at) VALUES ('GSAP-1777060907559', 'المكان', 'TITLE', 'SUBTITLE', 'الوصف هنا...', '/uploads/general/1777060914316_270.webp', '/products', NULL, 1, 'Fri Apr 24 2026 23:01:58 GMT+0300 (Eastern European Summer Time)');

-- Table: marquee_settings (1 rows)
TRUNCATE TABLE marquee_settings;
INSERT INTO marquee_settings (id, enabled, created_at) VALUES ('main', 0, 'Sat Apr 25 2026 20:08:22 GMT+0300 (Eastern European Summer Time)');

-- Table: marquee_logos (1 rows)
TRUNCATE TABLE marquee_logos;
INSERT INTO marquee_logos (id, image_url, name_ar, name_en, strip, order_index, type, text_ar, text_en, color, background_color, speed, created_at) VALUES ('MQ-1777185573787', '/uploads/marquee/1777185571345_373.webp', 'سشي', 'asdas', '1', 0, 'image', '', '', '#ffffff', '#1a1a1a', 30, 'Sun Apr 26 2026 09:39:33 GMT+0300 (Eastern European Summer Time)');

-- Table: svg_marquee (1 rows)
TRUNCATE TABLE svg_marquee;
INSERT INTO svg_marquee (id, left_text_1, left_text_2, right_text_1, right_text_2, text_color, animation_duration, show_can, show_bg_svg, can_image_url, font_family, enabled, created_at) VALUES ('main', 'Sip, smile, repeat', 'Taste the sparkle', 'Sip, smile, repeat', 'Taste the sparkle', '#543b27', 42, 1, 1, NULL, 'Lilita One, sans-serif', 0, 'Sat Apr 25 2026 19:33:35 GMT+0300 (Eastern European Summer Time)');

-- Table: svg_marquee_items (empty)
TRUNCATE TABLE svg_marquee_items;

SET FOREIGN_KEY_CHECKS=1;
